from pathlib import Path
import json,math,statistics,sys,re
root=Path('build/nav_runtime')
def p95(values):return sorted(values)[math.ceil(.95*len(values))-1]
def med(values):return round(statistics.median(values),2) if values else None
def ms(u):return round(u/1000,2)
def summarize(frames):
 if not frames:return {}
 return {'frames':len(frames),'uiP95Ms':ms(p95([x[1] for x in frames])),'rasterP95Ms':ms(p95([x[2] for x in frames])),'over16_67ms':sum(max(f[1],f[2])>16667 for f in frames),'over4_17ms':sum(max(f[1],f[2])>4167 for f in frames)}
def process(d):
 raw=[json.loads(x) for x in (d/'events.jsonl').read_text('utf-8').splitlines()];drv=json.loads((d/'driver.json').read_text('utf-8'))
 ext=drv['events'];start=drv['start']
 def first(t):return next((e for e in raw+ext if e['type']==t),{})
 frames=first('frames').get('data',[])
 if not frames:return None
 frame_map={f[0]:f for f in frames}
 sends=[e for e in ext if e['type']=='send'];nav=[e for e in raw if e['type']=='navInput']
 navs=[];cursor=0
 for s in sends[:-1]:
  label=s['label'];expect={'movie':0,'anime':1,'tvSeries':2}[label]
  while cursor<len(nav) and nav[cursor]['us']<s['us']-1000:cursor+=1
  n=nav[cursor];cursor+=1
  assert n['idx']==expect,(d,s,n)
  pg=next(x for x in raw if x['type']=='page' and x['page']==label and x['at']>=n['us'])
  render=frame_map.get(pg['frame'])
  first_raster=next((f for f in frames if f[4]>=s['us']),None)
  navs.append(dict(label=label,sendUs=s['us'],inputCallbackMs=ms(n['us']-s['us']),firstRasterMs=ms(first_raster[4]-s['us']) if first_raster else None,cardPostFrameMs=ms(pg['at']-s['us']),cardRasterMs=ms(render[4]-s['us']) if render else None,frame=pg['frame']))
 ns=[f for f in frames if sends[0]['us']<=f[4]<sends[-1]['us']]
 v=first('visibleInteractive'); green=first('green'); texture=first('videoTexture')
 local=next(e for e in raw if e['type']=='page' and e['page']=='local')
 out=dict(repetition=d.name.split('_')[-1],startupLayoutAndVisibleMs=ms(v['us']-start),startupFirstClickSentMs=ms(sends[0]['us']-start),startupFirstClickAcceptedMs=ms(nav[0]['us']-start),startupLayoutRasterMs=ms(frame_map[local['frame']][4]-start) if local['frame'] in frame_map else None,mediaKitInitMs=ms(first('mediaKit').get('dur',0)),credentialInitMs=ms(first('credential').get('dur',0)),playInputMs=ms(first('playInput')['us']-sends[-1]['us']),nav=navs,navTiming=summarize(ns),totalTiming=summarize(frames),videoTextureMs=ms(texture['us']-sends[-1]['us']) if texture else None,videoGreenIntervalMs=[ms(green[k]-sends[-1]['us']) for k in ('lower','upper')] if green else None)
 return out,ns
def all_results():
 out={}
 for d in sorted((root/'raw').glob('*')):
  if not re.fullmatch(r'(before|after)_\d+_i\d+',d.name) or not (d/'driver.json').exists() or not (d/'events.jsonl').exists():continue
  result=process(d)
  if result is None:continue
  key='_'.join(d.name.split('_')[:2])
  o=out.setdefault(key,dict(runs=[],pooledFrames=[]))
  o['runs'].append(result[0]);o['pooledFrames'].extend(result[1])
 for o in out.values():
  runs=o['runs'];o['pooledNavTiming']=summarize(o.pop('pooledFrames'))
  keys=['startupLayoutAndVisibleMs','startupFirstClickAcceptedMs','mediaKitInitMs','credentialInitMs','videoTextureMs']
  o['median']={k:med([r[k] for r in runs if r[k] is not None]) for k in keys}
  for i in range(7):
   for k in ['inputCallbackMs','firstRasterMs','cardPostFrameMs','cardRasterMs']:
    o['median'][f'nav{i+1}_{k}']=med([r['nav'][i][k] for r in runs if r['nav'][i][k] is not None])
  for i in range(2):o['median'][f'videoGreen{["Lower","Upper"][i]}Ms']=med([r['videoGreenIntervalMs'][i] for r in runs if r['videoGreenIntervalMs']])
 return out
if __name__=='__main__':
 results=all_results();(root/'release_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),'utf-8')
 for name,data in results.items():print(name,len(data['runs']),data['pooledNavTiming'],data['median'])
